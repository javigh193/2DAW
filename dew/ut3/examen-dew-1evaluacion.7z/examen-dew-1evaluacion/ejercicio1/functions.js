class paciente {
    constructor(NHC, nombre, apellidos, fecha_de_nacimiento, sexo) {
       this.NHC = NHC;
       this.nombre = nombre;
       this.apellidos = apellidos;
       // espera como entrada un string parseable a fecha, por ejemplo: 1999,12,30 (Y:M:D)
       this.fecha_de_nacimiento = new Date(fecha_de_nacimiento);
       this.sexo = sexo;
       this.historial = [];
       alert(`Registrado nuevo paciente con nombre: ${this.nombre}, apellidos: ${this.apellidos}, fecha de nacimiento: ${this.fecha_de_nacimiento} y sexo: ${this.sexo}.`);
    }

    modificarNHC() {
        let new_NHC = prompt('Por favor, introduzca el nuevo valor para NHC:');
        this.NHC = new_NHC;
        alert(`Nuevo valor de NHC: ${this.NHC}`);
    }

    modificarNombre() {
        let new_nombre = prompt('Por favor, introduzca el nuevo nombre del paciente:');
        this.nombre = new_nombre;
        alert(`Nuevo nombre: ${this.nombre}`);
    }

    modificarApellidos() {
        let new_apellidos = prompt('Por favor, introduzca los nuevos apellidos del paciente:');
        this.apellidos = new_apellidos;
        alert(`Nuevos apellidos: ${this.apellidos}`);
    }

    modificarFechaNaciemiento() {
        let new_fecha_nacimiento = prompt('Por favor, introduzca la nueva fecha de nacimiento del paciente:');
        // espera como entrada un string parseable a fecha, por ejemplo: 1999,12,30 (Y:M:D)
        this.fecha_de_nacimiento = new Date(new_fecha_nacimiento);
        alert(`Nueva fecha de nacimiento: ${this.fecha_de_nacimiento}`);
    }

    modificarSexo() {
        let new_sexo = prompt('Por favor, introduzca el nuevo sexo del paciente:');
        this.sexo = new_sexo;
        alert(`Nuevo sexo: ${this.sexo}`);
    }

    // genera un episodio de acuerdo a los valores introducidos por prompt y lo añade al final el historial
    agregarEpisodio() {
        let id = prompt('Por favor, introduzca la id del episodio.');
        let fecha = prompt('Por favor, introduzca la fecha del episodio.');
        let diagnostico = prompt('Por favor, introduzca el diagnóstico del episodio.');
        let tratamiento = prompt('Por favor, introduzca el tratamiento del episodio.');
        let medico = prompt('Por favor, introduzca el médico responsable del episodio.');
        let new_episodio = {'ID': id, 'Fecha': new Date(fecha), 'Diagnostico': diagnostico, 'Tratamiento': tratamiento, 'Medico': medico};
        this.historial.push(new_episodio);
    }

    // itera el historial y comprueba la ID de cada uno de ellos hasta encontrar el solicitado
    modificarEpisodio(id) {
        for (let i=0; i<this.historial.length; i++){
            if (this.historial[i]['ID'] === id) {
                let fecha = prompt('Por favor, introduzca la nueva fecha del episodio.');
                let diagnostico = prompt('Por favor, introduzca el nuevo diagnóstico del episodio.');
                let tratamiento = prompt('Por favor, introduzca el nuevo tratamiento del episodio.');
                let medico = prompt('Por favor, introduzca el nuevo médico responsable del episodio.');
                this.historial[i] = {'ID': id, 'Fecha': new Date(fecha), 'Diagnostico': diagnostico, 'Tratamiento': tratamiento, 'Medico': medico};
            }
        }
    }

    mostrarHistorial() {
        for (let i=0; i<this.historial.length; i++) {
            console.log(this.historial[i])
        }
    }
}